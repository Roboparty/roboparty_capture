// Copyright (c) Orbbec Inc. All Rights Reserved.
// Licensed under the MIT License.

#include <libobsensor/ObSensor.hpp>

#include "utils.hpp"
#include <iostream>
#include <iomanip>
#include <mutex>
#include <thread>
#include <atomic>
#include <map>

std::shared_ptr<ob::Device> selectDevice(std::shared_ptr<ob::DeviceList> deviceList);

int main(void) try {
    // Create a context, for getting devices and sensors
    std::shared_ptr<ob::Context> context = std::make_shared<ob::Context>();

    // Query device list
    auto deviceList = context->queryDeviceList();
    if(deviceList->getCount() < 1) {
        std::cout << "No device found! Please connect a supported device and retry this program." << std::endl;
        std::cout << "\nPress any key to exit.";
        ob_smpl::waitForKeyPressed();
        exit(EXIT_FAILURE);
    }

    std::shared_ptr<ob::Device> device = nullptr;
    if(deviceList->getCount() == 1) {
        // If a single device is plugged in, the first one is selected by default
        device = deviceList->getDevice(0);
    }
    else {
        device = selectDevice(deviceList);
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Check LiDAR device
    if(!ob_smpl::isLiDARDevice(device)) {
        std::cout << "Invalid device, please connect a LiDAR device!" << std::endl;
        return -1;
    }

    std::cout << "\n------------------------------------------------------------------------\n";
    std::cout << "Please enter the output filename (with .bag extension) and press Enter to start recording: ";
    std::string filePath;
    std::getline(std::cin, filePath);
    std::string suffix = ".bag";
    if(filePath.compare(filePath.length() - suffix.length(), suffix.length(), suffix) != 0) {
        filePath.append(suffix);
    }

    // Create a pipeline the specified device
    auto pipe = std::make_shared<ob::Pipeline>(device);

    // Create a config and enable all streams
    std::shared_ptr<ob::Config> config     = std::make_shared<ob::Config>();
    auto                        sensorList = device->getSensorList();
    auto                        count      = sensorList->getCount();
    for(uint32_t i = 0; i < count; i++) {
        auto sensor      = sensorList->getSensor(i);
        auto sensorType  = sensor->getType();
        auto profileList = sensor->getStreamProfileList();  // Get profileList to create Sensor object in advance
        config->enableStream(sensorType);
    }

    std::mutex                      frameMutex;
    std::map<OBFrameType, uint64_t> frameCountMap;
    pipe->start(config, [&](std::shared_ptr<ob::FrameSet> frameSet) {
        if(frameSet == nullptr) {
            return;
        }

        std::lock_guard<std::mutex> lock(frameMutex);
        auto                        count = frameSet->getCount();
        for(uint32_t i = 0; i < count; i++) {
            auto frame = frameSet->getFrameByIndex(i);
            if(frame) {
                auto type = frame->getType();
                frameCountMap[type]++;
            }
        }
    });

    // Initialize recording device with output file
    auto     startTime    = ob_smpl::getNowTimesMs();
    uint32_t waitTime     = 1000;
    auto     recordDevice = std::make_shared<ob::RecordDevice>(device, filePath);

    // operation prompt
    std::cout << "Streams and recorder have started!" << std::endl;
    std::cout << "Press ESC, 'q', or 'Q' to stop recording and exit safely." << std::endl;
    std::cout << "IMPORTANT: Always use ESC/q/Q to stop! Otherwise, the bag file will be corrupted and unplayable." << std::endl << std::endl;

    do {
        auto key = ob_smpl::waitForKeyPressed(50);
        if(key == ESC_KEY || key == 'q' || key == 'Q') {
            break;
        }
        auto currentTime = ob_smpl::getNowTimesMs();
        if(currentTime > startTime + waitTime) {
            std::map<OBFrameType, uint64_t> tempCountMap;
            uint64_t                        duration;
            {
                // Copy data
                std::lock_guard<std::mutex> lock(frameMutex);

                // get time again
                currentTime = ob_smpl::getNowTimesMs();
                duration    = currentTime - startTime;
                if(!frameCountMap.empty()) {
                    startTime    = currentTime;
                    waitTime     = 2000;  // Change to 2s for next time
                    tempCountMap = frameCountMap;
                    for(auto &item: frameCountMap) {
                        item.second = 0;  // reset count
                    }
                }
            }

            std::string seperate = "";
            if(tempCountMap.empty()) {
                std::cout << "Recording... Current FPS: 0" << std::endl;
            }
            else {
                std::cout << "Recording... Current FPS: ";
                for(const auto &item: tempCountMap) {
                    auto  name = ob::TypeHelper::convertOBFrameTypeToString(item.first);
                    float rate = item.second / (duration / 1000.0f);

                    std::cout << std::fixed << std::setprecision(2) << std::showpoint;
                    std::cout << seperate << name << "=" << rate;
                    seperate = ", ";
                }
                std::cout << std::endl;
            }
        }
    } while(true);

    // stop the pipeline
    pipe->stop();

    // Flush and save recording file
    recordDevice = nullptr;
    return 0;
}
catch(ob::Error &e) {
    std::cerr << "Function: " << e.getFunction() << "\nArgs: " << e.getArgs() << "\nMessage: " << e.what() << "\nStatus: " << e.getStatus()
              << "\nException Type: " << e.getExceptionType() << std::endl;
    std::cout << "\nPress any key to exit.";
    ob_smpl::waitForKeyPressed();
    exit(EXIT_FAILURE);
}

// Select a device, the name, pid, vid, uid of the device will be printed here, and the corresponding device object will be created after selection
std::shared_ptr<ob::Device> selectDevice(std::shared_ptr<ob::DeviceList> deviceList) {
    int devCount = deviceList->getCount();
    std::cout << "Device list: " << std::endl;
    for(int i = 0; i < devCount; i++) {
        std::cout << i << ". name: " << deviceList->getName(i) << ", vid: 0x" << std::hex << deviceList->getVid(i) << ", pid: 0x" << std::setw(4)
                  << std::setfill('0') << deviceList->getPid(i) << ", uid: 0x" << deviceList->getUid(i) << ", sn: " << deviceList->getSerialNumber(i)
                  << std::dec << std::endl;
    }
    std::cout << "Select a device: ";

    int devIndex;
    std::cin >> devIndex;
    while(devIndex < 0 || devIndex >= devCount || std::cin.fail()) {
        std::cin.clear();
        std::cin.ignore();
        std::cout << "Your select is out of range, please reselect: " << std::endl;
        std::cin >> devIndex;
    }

    return deviceList->getDevice(devIndex);
}