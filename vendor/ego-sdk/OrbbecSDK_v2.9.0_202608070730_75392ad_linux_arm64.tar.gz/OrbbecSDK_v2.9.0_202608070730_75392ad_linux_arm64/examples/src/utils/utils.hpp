// Copyright (c) Orbbec Inc. All Rights Reserved.
// Licensed under the MIT License.

#pragma once
#include <stdint.h>
#include "utils_types.h"

#include <sstream>
#include <libobsensor/ObSensor.hpp>

namespace ob_smpl {
char waitForKeyPressed(uint32_t timeout_ms = 0);

uint64_t getNowTimesMs();

int getInputOption();

template <typename T> std::string toString(const T a_value, const int n = 6) {
    std::ostringstream out;
    out.precision(n);
    out << std::fixed << a_value;
    return std::move(out).str();
}

/**
 * @brief Check if the device is a LiDAR device.
 *
 * @param device The device to check.
 * @return true if the device is a LiDAR device.
 * @return false otherwise.
 */
bool isLiDARDevice(std::shared_ptr<ob::Device> device);

bool supportAnsiEscape();

/**
 * @brief Check if the device is a Gemini305 device.
 *
 * @param vid The vendor ID of the device.
 * @param pid The product ID of the device.
 * @return true if the device is a Gemini 305 device.
 * @return false otherwise.
 */
bool isGemini305Device(int vid, int pid);

/**
 * @brief Check if the device is a Gemini305 device.
 *
 * @param vid The vendor ID of the device.
 * @param pid The product ID of the device.
 * @param connectionType The connection type of the device.
 * @return true if the device is a Gemini 305g device.
 * @return false otherwise.
 */
bool isGemini305gDevice(int vid, int pid, const char *connectionType);

/**
 * @brief Check if the device is a Astra Mini device.
 *
 * @param vid The vendor ID of the device.
 * @param pid The product ID of the device.
 * @return true if the device is a Astra Mini device.
 * @return false otherwise.
 */
bool isAstraMiniDevice(int vid, int pid);

/**
 * @brief Check if the device is a Dabai A series device.
 *
 * @param vid The vendor ID of the device.
 * @param pid The product ID of the device.
 * @return true if the device is a Dabai A series device.
 * @return false otherwise.
 */
bool isDabaiASeriesDevice(int vid, int pid);

class StreamStateGuard {
public:
    explicit StreamStateGuard(std::ios &s) : ios(s), flags(s.flags()), fill(s.fill()) {}
    ~StreamStateGuard() {
        ios.flags(flags);
        ios.fill(fill);
    }

private:
    std::ios          &ios;
    std::ios::fmtflags flags;
    char               fill{ 0 };
};

}  // namespace ob_smpl
