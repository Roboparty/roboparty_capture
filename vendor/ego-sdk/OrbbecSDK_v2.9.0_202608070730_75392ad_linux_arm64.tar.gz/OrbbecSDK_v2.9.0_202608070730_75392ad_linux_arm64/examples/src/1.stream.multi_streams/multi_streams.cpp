// Copyright (c) Orbbec Inc. All Rights Reserved.
// Licensed under the MIT License.

#include <libobsensor/ObSensor.h>

#include "utils.hpp"
#include "utils_opencv.hpp"

#include <mutex>
#include <thread>

static std::mutex statusMutex;
static void printPipelineStatus(const std::string &title, OBPipelineStatus status) {
    std::lock_guard<std::mutex> lock(statusMutex);
    ob_smpl::StreamStateGuard guard(std::cout);
    std::cout << "--------------------------------------------------------------------------------" << std::endl;
    std::cout << "Pipeline status(" << title << "): " << std::endl;
    if(status.issue & OB_PIPELINE_ISSUE_SDK) {
        std::cout << "Issue observed in SDK, status: 0x" << std::hex << status.sdkStatus << std::endl;
    }
    if(status.issue & OB_PIPELINE_ISSUE_DRIVER) {
        std::cout << "Issue observed in driver, status: 0x" << std::hex << status.drvStatus << std::endl;
    }
    if(status.issue & (OB_PIPELINE_ISSUE_FW | OB_PIPELINE_ISSUE_HW)) {
        std::cout << "Issue observed in device, status: 0x" << std::hex << status.devStatus << std::endl;
    }
    std::cout << "--------------------------------------------------------------------------------\n" << std::endl;
}

int main(void) try {

    // Create a pipeline with default device.
    ob::Pipeline pipe;

    // Configure which streams to enable or disable for the Pipeline by creating a Config.
    std::shared_ptr<ob::Config> config = std::make_shared<ob::Config>();

    // Enumerate and config all sensors.
    auto device  = pipe.getDevice();
    auto devInfo = device->getDeviceInfo();
    auto pid     = devInfo->getPid();
    auto vid     = devInfo->getVid();

    // Get sensor list from device.
    auto sensorList = device->getSensorList();

    bool supportIMU = false;
    for(uint32_t i = 0; i < sensorList->getCount(); i++) {
        // Get sensor type.
        auto sensorType = sensorList->getSensorType(i);

        // exclude gyro and accel sensors.
        if(sensorType == OB_SENSOR_GYRO || sensorType == OB_SENSOR_ACCEL) {
            supportIMU = true;
            continue;
        }

        if(ob_smpl::isAstraMiniDevice(vid, pid)) {
            if(sensorType == OB_SENSOR_COLOR) {
                continue;
            }
        }

        // enable the stream.
        config->enableStream(sensorType);
    }
    if(ob_smpl::isGemini305gDevice(vid, pid, devInfo->getConnectionType())) {
        config->disableStream(OB_SENSOR_IR_LEFT);
    }

    // enable health monitor
    pipe.enableHealthMonitor([&](OBPipelineStatus status) { printPipelineStatus("video", status); });
    // Start the pipeline with config
    std::mutex                          frameMutex;
    std::shared_ptr<const ob::FrameSet> renderFrameSet;
    pipe.start(config, [&](std::shared_ptr<ob::FrameSet> frameSet) {
        std::lock_guard<std::mutex> lock(frameMutex);
        renderFrameSet = frameSet;
    });

    if(supportIMU) {
        // The IMU frame rate is much faster than the video, so it is advisable to use a separate pipeline to obtain IMU data.
        auto                                dev         = pipe.getDevice();
        auto                                imuPipeline = std::make_shared<ob::Pipeline>(dev);
        std::mutex                          imuFrameMutex;
        std::shared_ptr<const ob::FrameSet> renderImuFrameSet;

        std::shared_ptr<ob::Config> imuConfig = std::make_shared<ob::Config>();
        // enable gyro stream.
        imuConfig->enableGyroStream();
        // enable accel stream.
        imuConfig->enableAccelStream();
        // enable health monitor
        imuPipeline->enableHealthMonitor([&](OBPipelineStatus status) { printPipelineStatus("imu", status); });
        // start the imu pipeline.
        imuPipeline->start(imuConfig, [&](std::shared_ptr<ob::FrameSet> frameSet) {
            std::lock_guard<std::mutex> lockImu(imuFrameMutex);
            renderImuFrameSet = frameSet;
        });

        // Create a window for rendering and set the resolution of the window
        ob_smpl::CVWindow win("MultiStream", 1280, 720, ob_smpl::ARRANGE_GRID);
        while(win.run()) {
            std::lock_guard<std::mutex> lockImu(imuFrameMutex);
            std::lock_guard<std::mutex> lock(frameMutex);

            if(renderFrameSet == nullptr || renderImuFrameSet == nullptr) {
                continue;
            }
            // Render camera and imu frameset.
            win.pushFramesToView({ renderFrameSet, renderImuFrameSet });
        }

        // Stop the Pipeline, no frame data will be generated.
        pipe.stop();

        if(supportIMU) {
            // disable health monitor
            imuPipeline->disableHealthMonitor();
            // Stop the IMU Pipeline, no frame data will be generated.
            imuPipeline->stop();
        }
    }
    else {
        // Create a window for rendering and set the resolution of the window
        ob_smpl::CVWindow win("MultiStream", 1280, 720, ob_smpl::ARRANGE_GRID);
        while(win.run()) {
            std::lock_guard<std::mutex> lock(frameMutex);

            if(renderFrameSet == nullptr) {
                continue;
            }
            // Render camera and imu frameset.
            win.pushFramesToView(renderFrameSet);
        }

        // disable health monitor
        pipe.disableHealthMonitor();
        // Stop the Pipeline, no frame data will be generated.
        pipe.stop();
    }

    return 0;
}
catch(ob::Error &e) {
    std::cerr << "function:" << e.getFunction() << "\nargs:" << e.getArgs() << "\nmessage:" << e.what() << "\nstatus:" << e.getStatus()
              << "\ntype:" << e.getExceptionType() << std::endl;
    std::cout << "\nPress any key to exit.";
    ob_smpl::waitForKeyPressed();
    exit(EXIT_FAILURE);
}

